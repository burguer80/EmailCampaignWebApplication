class MixedCaseMonkey < ActiveRecord::Base
  set_primary_key 'monkeyID'
end
