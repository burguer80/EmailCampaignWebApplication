DROP TABLE courses;

