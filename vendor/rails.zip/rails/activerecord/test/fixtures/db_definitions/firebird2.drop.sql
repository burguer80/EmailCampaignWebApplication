DROP TABLE courses;
DROP GENERATOR courses_seq;
