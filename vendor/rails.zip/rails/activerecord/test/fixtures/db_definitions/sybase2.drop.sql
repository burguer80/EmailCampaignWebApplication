DROP TABLE courses
go


