require 'bigdecimal'

require File.dirname(__FILE__) + '/bigdecimal/formatting.rb'
