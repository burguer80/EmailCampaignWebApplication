module Fun::GamesHelper
  def stratego() "Iz guuut!" end
end